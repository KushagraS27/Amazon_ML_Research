 #!/usr/bin/env python3
## Spark-3
from __future__ import annotations

import os
import re
import sys
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression

BASE = os.path.dirname(os.path.abspath(__file__))
TRN_CSV = os.path.join(BASE, "training_data.csv")
TST_CSV = os.path.join(BASE, "test_data.csv")
PDF = os.path.join(BASE, "uploads", "CPRI_Hackathon_Screening_Dataset_PARTICIPANT (1).pdf")
if not os.path.exists(PDF):
    # fall back: any pdf in BASE or BASE/uploads
    for cand in (os.path.join(BASE, "CPRI_Hackathon_Screening_Dataset_PARTICIPANT (1).pdf"),):
        if os.path.exists(cand):
            PDF = cand
            break

NUM_RE = re.compile(r"^-?\d+(?:\.\d+)?$")          # bare numeric token

NUM = ["Applied_Voltage_kV", "Load_Current_A", "Ambient_Temperature_C",
       "Test_Duration_min", "Sensor_S1", "Sensor_S2", "Sensor_S3", "Sensor_S4"]
PRIM = NUM[:4]
NCOLS = ["Test_ID"] + NUM   # full 9-column table layout used by the extractor
SENSORS = ["Sensor_S1", "Sensor_S2", "Sensor_S3"]          # information-carrying
REGIME_I = 62.0        # load-current threshold of the genuine regime change [A]
TEMP_HINGE = 45.0      # high-temperature behavioural hinge [degC]
Z_TH = 4.0             # anomaly threshold (sigma) - 4sigma gap between classes
MISSING_Z = 15.0       # severity assigned to a missing critical sensor
DUP_BONUS = 3.0        # severity bonus for duplicated measurement pairs


# ============================================================================
# PART A - DATA EXTRACTION FROM THE SCREENING PDF
# The PDF stores the two tables as page-sliced column groups:
#   * Training (pages 4-20, landscape): all 11 columns per page.
#   * Test (pages 21-44, portrait), column groups per page slot:
#       slot 0..7: P21-28 : Test_ID, V, I, T
#       slot 0..7: P29-36 : Test_Duration_min, Sensor_S1, Sensor_S2, Sensor_S3
#       slot 0..7: P37-44 : Sensor_S4
# Rows within a slot are vertically aligned across the groups, so numeric
# groups are joined to the ID group by matching row 'top' coordinates;
# missing cells become NaN in exactly the right row (14pt row pitch).
# ============================================================================
def is_num(t):
    return bool(NUM_RE.match(t))


def rows_of(words, tol=3.0):
    if not words:
        return []
    tops = sorted(set(round(w["top"], 1) for w in words))
    clusters, cur = [], [tops[0]]
    for t in tops[1:]:
        if t - cur[-1] <= tol:
            cur.append(t)
        else:
            clusters.append(sum(cur) / len(cur))
            cur = [t]
    clusters.append(sum(cur) / len(cur))
    bucket = {i: [] for i in range(len(clusters))}
    for w in words:
        t = round(w["top"], 1)
        bucket[min(range(len(clusters)), key=lambda i: abs(clusters[i] - t))].append(w)
    return [(clusters[i], sorted(bucket[i], key=lambda w: w["x0"])) for i in range(len(clusters))]


def cluster_centers(vals, tol=30):
    vals = sorted(vals)
    out, cur = [], [vals[0]]
    for v in vals[1:]:
        if v - cur[-1] <= tol:
            cur.append(v)
        else:
            out.append(sum(cur) / len(cur))
            cur = [v]
    out.append(sum(cur) / len(cur))
    return out


def is_header_row(txts, group_cols):
    if any(t.startswith("TST-") or is_num(t) for t in txts):
        return False
    return all(t in group_cols or t in ("Ambient_Temperatu", "re_C", "Test_Duration_min",
                                        "Sensor_S4") for t in txts)


def extract_training(pdf):
    centers = {"Applied_Voltage_kV": 141, "Load_Current_A": 206, "Ambient_Temperature_C": 271,
               "Test_Duration_min": 336, "Sensor_S1": 400, "Sensor_S2": 465, "Sensor_S3": 530,
               "Sensor_S4": 595, "Reference_Parameter": 660, "Validity_Label": 689}
    records = []
    for pi in range(3, 20):
        for top, ws in rows_of(pdf.pages[pi].extract_words()):
            tid = next((w["text"] for w in ws if w["text"].startswith("TRN-")), None)
            if tid is None:
                continue
            rec = {"Test_ID": tid, **{c: None for c in centers}}
            for w in ws:
                if w["text"].startswith("TRN-"):
                    continue
                t = w["text"]
                m = re.match(r"^(-?\d+(?:\.\d+)?)(Valid|Invalid)$", t)
                if m:
                    rec["Reference_Parameter"], rec["Validity_Label"] = float(m.group(1)), m.group(2)
                    continue
                if t in ("Valid", "Invalid"):
                    rec["Validity_Label"] = t
                    continue
                if not is_num(t):
                    continue
                best = min(centers, key=lambda c: abs(centers[c] - w["x0"]))
                if abs(centers[best] - w["x0"]) < 40:
                    rec[best] = float(t)
            records.append(rec)
    return records

# ------------------------------------------------------------------- TEST
def extract_test(pdf):
    id_pages, dur_pages, s4_pages = list(range(20, 28)), list(range(28, 36)), list(range(36, 44))

    # 1) ID group: ordered records + row top per slot
    slot_rows = {}  # slot -> list of (top, {col: value})
    for slot, pi in enumerate(id_pages):
        entries = []
        for top, ws in rows_of(pdf.pages[pi].extract_words()):
            txts = [w["text"] for w in ws]
            if is_header_row(txts, NCOLS[:4]):
                continue
            entry = {"top": top}
            for w in ws:
                if w["text"].startswith("TST-"):
                    entry["Test_ID"] = w["text"]
                elif is_num(w["text"]):
                    entry.setdefault("num", []).append((w["x0"], float(w["text"])))
            entries.append(entry)
        if not entries:
            continue
        # column centers for the 3 numeric cols from all numeric words
        allx = [x for e in entries for x, _ in e.get("num", [])]
        cc = cluster_centers(allx)
        for e in entries:
            for x, v in e.pop("num", []):
                ci = min(range(len(cc)), key=lambda i: abs(cc[i] - x))
                e[["Applied_Voltage_kV", "Load_Current_A", "Ambient_Temperature_C"][ci]] = v
        slot_rows[slot] = entries

    records = []
    for slot in range(8):
        records.extend(slot_rows[slot])
    n = len(records)

    # 2) numeric groups joined by (slot, top)
    def join(pi_list, col_names, group_cols):
        for slot, pi in enumerate(pi_list):
            top_map = {round(e["top"], 1): e for e in slot_rows[slot]}
            for top, ws in rows_of(pdf.pages[pi].extract_words()):
                txts = [w["text"] for w in ws]
                if is_header_row(txts, group_cols):
                    continue
                num = [(w["x0"], w["text"]) for w in ws if is_num(w["text"])]
                if not num:
                    continue
                tgt = min(top_map, key=lambda t: abs(t - round(top, 1)))
                if abs(tgt - round(top, 1)) > 2:
                    raise RuntimeError(f"row top {top} not found in slot {slot}")
                xs = [x for x, _ in num]
                cc = cluster_centers(xs)
                for x, t in num:
                    ci = min(range(len(cc)), key=lambda i: abs(cc[i] - x))
                    top_map[tgt][col_names[ci]] = float(t)

    join(dur_pages, ["Test_Duration_min", "Sensor_S1", "Sensor_S2", "Sensor_S3"], NCOLS[4:8])
    join(s4_pages, ["Sensor_S4"], ["Sensor_S4"])

    frame = [{c: r.get(c) for c in NCOLS} | {"Test_ID": r.get("Test_ID")} for r in records]
    # fill Test_ID from id col
    return pd.DataFrame(frame, columns=NCOLS), n





def ensure_data() -> tuple[pd.DataFrame, pd.DataFrame]:
    """Load CSVs; re-extract from the PDF if they are missing."""
    if not (os.path.exists(TRN_CSV) and os.path.exists(TST_CSV)):
        try:
            import pdfplumber
        except ImportError:
            sys.exit("training_data.csv / test_data.csv missing and pdfplumber not "
                     "installed. Run:  pip install pdfplumber")
        print("[data] CSVs missing - re-extracting from the screening PDF ...")
        _extract_all()
    trn = pd.read_csv(TRN_CSV)
    tst = pd.read_csv(TST_CSV)
    return trn, tst


def _extract_all() -> None:
    import pdfplumber
    pdf = pdfplumber.open(PDF)
    train = extract_training(pdf)
    tst, n_test = extract_test(pdf)
    pdf.close()

    tcols = NCOLS + ["Reference_Parameter", "Validity_Label"]
    trn = pd.DataFrame(train, columns=tcols)
    trn.to_csv(TRN_CSV, index=False)
    print(f"[data] training rows: {len(trn)}  unique ids: {trn.Test_ID.nunique()}")

    tst.to_csv(TST_CSV, index=False)
    print(f"[data] test rows: {len(tst)}  unique ids: {tst.Test_ID.nunique()}")


# ============================================================================
# PART B - TASK 01: MODEL + ANOMALY DETECTION
# ============================================================================
# ----------------------------------------------------------------------------
# Model fitting (uses ONLY verified training records)
# ----------------------------------------------------------------------------
class PlantModel:
    """Physics-based plant model fitted on verified (labelled-Valid) data."""

    def __init__(self, trn: pd.DataFrame):
        clean = trn[trn.Validity_Label == "Valid"].dropna(subset=NUM)
        clean = clean[~clean.duplicated(subset=NUM)].reset_index(drop=True)
        self.n_clean = len(clean)

        # --- sensor physics models S1, S2, S3 ~ (V, I, T, D)
        self.sens_lr, self.sens_sd, self.sens_r2 = {}, {}, {}
        for s in SENSORS:
            lr = LinearRegression().fit(clean[PRIM].values, clean[s].values)
            self.sens_lr[s] = lr
            self.sens_sd[s] = float((clean[s].values - lr.predict(clean[PRIM].values)).std())
            self.sens_r2[s] = 1 - float(((clean[s].values - lr.predict(clean[PRIM].values))**2).sum()
                                        / ((clean[s].values - clean[s].mean())**2).sum())

        # --- Reference models, one per operating regime
        I = clean.Load_Current_A.values
        maskA, maskB = I <= REGIME_I, I > REGIME_I
        X = self._design(clean)
        y = clean.Reference_Parameter.values
        self.refA = LinearRegression(fit_intercept=False).fit(X[maskA], y[maskA])
        self.refB = LinearRegression(fit_intercept=False).fit(X[maskB], y[maskB])
        self.sigA = float((y[maskA] - X[maskA] @ self.refA.coef_).std())
        self.sigB = float((y[maskB] - X[maskB] @ self.refB.coef_).std())
        self.nA, self.nB = int(maskA.sum()), int(maskB.sum())

    @staticmethod
    def _design(df: pd.DataFrame) -> np.ndarray:
        I = df.Load_Current_A.values
        T = df.Ambient_Temperature_C.values
        S2 = df.Sensor_S2.values
        h = np.maximum(0.0, T - TEMP_HINGE)          # high-temperature ramp
        return np.column_stack([np.ones(len(df)), I, I**2, S2, T, h, h**2])

    # ------------------------------------------------------------- inference
    def sensor_z(self, df: pd.DataFrame) -> pd.DataFrame:
        """Standardised deviation of each sensor from its physics law."""
        out = {}
        for s in SENSORS:
            expect = df[PRIM].values @ self.sens_lr[s].coef_
            out[s] = (df[s].values - expect) / self.sens_sd[s]
        return pd.DataFrame(out, index=df.index)

    def sensor_hat(self, df: pd.DataFrame) -> pd.DataFrame:
        """Physics-imputed sensor values (used to replace corrupted readings)."""
        return pd.DataFrame(
            {s: df[PRIM].values @ self.sens_lr[s].coef_ for s in SENSORS}, index=df.index)

    def predict_reference(self, df: pd.DataFrame, s2: np.ndarray) -> pd.DataFrame:
        """Reference prediction from (V, I, T, D, S2) with regime awareness.
        `s2` is the S2 value actually used (observed or imputed)."""
        d = df.assign(Sensor_S2=s2)
        X = self._design(d)
        regime = (d.Load_Current_A.values > REGIME_I).astype(int)
        pred = np.where(regime == 1, X @ self.refB.coef_, X @ self.refA.coef_)
        sigma = np.where(regime == 1, self.sigB, self.sigA)
        return pd.DataFrame({"Predicted_Reference_Parameter": pred,
                             "Prediction_Sigma": sigma,
                             "Regime": np.where(regime == 1, "B (I>62A)", "A (I<=62A)")},
                            index=df.index)

    def reference_z(self, df: pd.DataFrame, ref: pd.Series) -> pd.Series:
        """Standardised Reference residual (only where a Reference exists)."""
        X = self._design(df)
        regime = (df.Load_Current_A.values > REGIME_I).astype(int)
        expect = np.where(regime == 1, X @ self.refB.coef_, X @ self.refA.coef_)
        sigma = np.where(regime == 1, self.sigB, self.sigA)
        return pd.Series(np.abs(ref.values - expect) / sigma, index=df.index)


# ----------------------------------------------------------------------------
# Task 01 - anomaly diagnosis
# ----------------------------------------------------------------------------
def diagnose(df: pd.DataFrame, model: PlantModel, has_reference: bool) -> pd.DataFrame:
    """Return a per-record diagnosis frame with categories and severity."""
    z = model.sensor_z(df)

    dup = df.duplicated(subset=NUM, keep=False)
    miss_crit = df[SENSORS].isna().any(axis=1)
    miss_s4 = df.Sensor_S4.isna()

    invalid = (z.abs() > Z_TH).any(axis=1) | miss_crit | dup
    zref = model.reference_z(df, df.Reference_Parameter) if has_reference \
        else pd.Series(np.nan, index=df.index)
    ref_bad = (zref > Z_TH) if has_reference else pd.Series(False, index=df.index)
    invalid = invalid | ref_bad

    def category(i):
        flags = []
        bad = [s for s in SENSORS if not np.isnan(z[s].iloc[i]) and abs(z[s].iloc[i]) > Z_TH]
        if bad:
            flags.append("sensor_error:" + ",".join(b.replace("Sensor_S", "S") for b in bad))
        if miss_crit.iloc[i]:
            flags.append("invalid_test_condition:missing " +
                         ",".join(s.replace("Sensor_S", "S") for s in SENSORS if pd.isna(df[s].iloc[i])))
        if dup.iloc[i]:
            flags.append("corrupted_data:duplicated_measurement_pair")
        if ref_bad.iloc[i]:
            flags.append("reference_measurement_error")
        return "; ".join(flags) if flags else ""

    out = pd.DataFrame(index=df.index)
    out["Test_ID"] = df.Test_ID.values
    out["z_S1"], out["z_S2"], out["z_S3"] = z["Sensor_S1"].values, z["Sensor_S2"].values, z["Sensor_S3"].values
    out["z_Reference"] = zref.values
    out["Duplicate_Pair"] = dup
    out["Missing_Critical_Sensor"] = miss_crit
    out["Missing_S4"] = miss_s4
    out["Validity_Label"] = np.where(invalid, "Invalid", "Valid")
    out["Anomaly_Reasons"] = [category(i) for i in range(len(df))]
    # severity: worst sensor z (missing critical sensor -> floor), duplicate bonus
    sev = z.abs().max(axis=1).fillna(0.0)
    sev = np.maximum(sev, np.where(miss_crit, MISSING_Z, 0.0))
    out["Severity_Score"] = sev + np.where(dup, DUP_BONUS, 0.0)
    out["Regime"] = np.where(df.Load_Current_A.values > REGIME_I,
                             "B (I>62A)", "A (I<=62A)")
    return out


# ----------------------------------------------------------------------------
# Task 02 - reference prediction for the test set
# ----------------------------------------------------------------------------
def predict(model: PlantModel, tst: pd.DataFrame) -> pd.DataFrame:
    z = model.sensor_z(tst)
    hat = model.sensor_hat(tst)
    # replace a corrupted S2 (the Reference driver) by its physics-imputed value
    s2_use = tst.Sensor_S2.where(z["Sensor_S2"].abs() <= Z_TH, hat["Sensor_S2"]).values
    pred = model.predict_reference(tst, s2_use)
    pred["S2_Imputed"] = (z["Sensor_S2"].abs() > Z_TH)
    return pred


# ----------------------------------------------------------------------------
# Task 03 - automated summary
# ----------------------------------------------------------------------------
def build_summary_final(diag_tst: pd.DataFrame, pred: pd.DataFrame) -> str:
    """Clean summary writer (top-3 listed explicitly)."""
    n = len(diag_tst)
    n_inv = int((diag_tst.Validity_Label == "Invalid").sum())
    pmin = float(pred.Predicted_Reference_Parameter.min())
    pmax = float(pred.Predicted_Reference_Parameter.max())
    pavg = float(pred.Predicted_Reference_Parameter.mean())
    top3 = diag_tst.sort_values("Severity_Score", ascending=False).head(3)
    n_sens = int(diag_tst.Anomaly_Reasons.str.contains("sensor_error").sum())
    n_dup = int(diag_tst.Duplicate_Pair.sum())
    n_miss = int(diag_tst.Missing_Critical_Sensor.sum())

    expl = (
        "We fit a physics based model on the verified training records. Sensors S1, S2, S3 obey "
        "deterministic laws from voltage, current, temperature and duration; the Reference "
        "follows two load current regimes split at 62 amperes plus a high temperature drift "
        "above 45 degrees. Sensor S4 carries no process information. A record is invalid when a "
        "sensor deviates more than 4 sigma from its law, when inputs duplicate another record, "
        "or when a critical sensor is missing. The regime change is modelled as genuine "
        "behaviour, not flagged. Corrupted S2 readings are physics imputed before prediction."
    )
    n_words = len(expl.split())
    n_words_strict = len(re.findall(r"[A-Za-z0-9][A-Za-z0-9.%]*", expl))
    assert n_words <= 100 and n_words_strict <= 100, \
        f"explanation too long: {n_words} / {n_words_strict} words"

    L = []
    L.append("=" * 78)
    L.append(" CPRI SCREENING ROUND - AUTOMATED TEST SUMMARY")
    L.append("=" * 78)
    L.append(f"Records analysed .................... {n}")
    L.append(f"Abnormal / invalid records .......... {n_inv}")
    L.append(f"    - sensor error (S1/S2/S3 off physics law): {n_sens}")
    L.append(f"    - missing critical sensor (S1/S2/S3) ....: {n_miss}")
    L.append(f"    - duplicated measurement pairs ..........: {n_dup}")
    L.append(f"Minimum predicted Reference Parameter  {pmin:.4f}")
    L.append(f"Maximum predicted Reference Parameter  {pmax:.4f}")
    L.append(f"Average predicted Reference Parameter  {pavg:.4f}")
    L.append("Three Test IDs requiring the highest attention:")
    for k, (_, r) in enumerate(top3.iterrows(), 1):
        L.append(f"    {k}. {r.Test_ID}  (severity {r.Severity_Score:.1f})  [{r.Anomaly_Reasons}]")
    L.append("")
    L.append(f"How we approached the problem ({n_words} words):")
    L.append(expl)
    L.append("=" * 78)
    return "\n".join(L)


# ----------------------------------------------------------------------------
# Validation on the training set (labels are available there)
# ----------------------------------------------------------------------------
def validate_training(trn: pd.DataFrame, model: PlantModel, diag: pd.DataFrame) -> None:
    truth = (trn.Validity_Label == "Invalid").to_numpy()
    pred_inv = (diag.Validity_Label == "Invalid").to_numpy()
    tp, fn, fp, tn = int((truth & pred_inv).sum()), int((truth & ~pred_inv).sum()), \
                     int((~truth & pred_inv).sum()), int((~truth & ~pred_inv).sum())
    print("\n--- Task 01 validation on the labelled training set ---------------")
    print(f"Invalid records: {int(truth.sum())}  |  detected: {int(pred_inv.sum())}")
    print(f"TP={tp}  FN={fn}  FP={fp}  TN={tn}")
    print(f"Recall = {tp/(tp+fn):.3f}   Precision = {tp/(tp+fp):.3f}   Accuracy = {(tp+tn)/len(truth):.4f}")
    if fn:
        print("Missed invalid records (for the record):")
        print(trn[truth & ~pred_inv][["Test_ID"]].to_string(index=False))
    if fp:
        print("False-positive valid records (genuine extreme-but-valid data):")
        print(trn[~truth & pred_inv][["Test_ID", "Reference_Parameter"]].to_string(index=False))


# ----------------------------------------------------------------------------


# ============================================================================
# ORCHESTRATION - run all three tasks
# ============================================================================
def main() -> None:
    np.set_printoptions(suppress=True)
    trn, tst = ensure_data()
    print(f"[data] training records: {len(trn)}   test records: {len(tst)}")

    model = PlantModel(trn)
    print(f"[model] fitted on {model.n_clean} verified records")
    print(f"[model] sensor physics R2: " +
          ", ".join(f"{s.replace('Sensor_S','S')}={model.sens_r2[s]:.4f}" for s in SENSORS) +
          f"   (sigma: " + ", ".join(f"{model.sens_sd[s]:.3f}" for s in SENSORS) + ")")
    print(f"[model] reference regimes: A n={model.nA} sigma={model.sigA:.3f} | "
          f"B n={model.nB} sigma={model.sigB:.3f}   (threshold I > {REGIME_I} A)")

    # ---------------- Task 01 (both sets; Reference check only where observed)
    diag_trn = diagnose(trn, model, has_reference=True)
    diag_tst = diagnose(tst, model, has_reference=False)
    validate_training(trn, model, diag_trn)

    print("\n--- Task 01 results on the test set ------------------------------")
    print(diag_tst[diag_tst.Validity_Label == "Invalid"]
          [["Test_ID", "z_S1", "z_S2", "z_S3", "Missing_Critical_Sensor",
            "Duplicate_Pair", "Severity_Score", "Anomaly_Reasons"]]
          .round(2).to_string(index=False))

    # ---------------- Task 02
    pred = predict(model, tst)
    out = pd.DataFrame({
        "Test_ID": tst.Test_ID.values,
        "Predicted_Reference_Parameter": pred.Predicted_Reference_Parameter.round(4).values,
        "Validity_Label": diag_tst.Validity_Label.values,
    })
    out.to_csv(os.path.join(BASE, "submission.csv"), index=False)
    print(f"\n[task2] predicted Reference for all {len(out)} test records -> submission.csv")
    print(f"[task2] prediction range: {out.Predicted_Reference_Parameter.min():.3f} .. "
          f"{out.Predicted_Reference_Parameter.max():.3f}   mean {out.Predicted_Reference_Parameter.mean():.3f}")
    print(f"[task2] S2 imputed for {int(pred.S2_Imputed.sum())} corrupted records")

    detail = pd.concat([diag_tst, pred[["Predicted_Reference_Parameter",
                                       "Prediction_Sigma", "S2_Imputed"]]], axis=1)
    detail.to_csv(os.path.join(BASE, "test_analysis.csv"), index=False)
    diag_trn.to_csv(os.path.join(BASE, "training_analysis.csv"), index=False)

    # ---------------- Task 03
    summary = build_summary_final(diag_tst, pred)
    with open(os.path.join(BASE, "test_summary.txt"), "w") as f:
        f.write(summary + "\n")
    print("\n[task3] automatic summary -> test_summary.txt\n")
    print(summary)


if __name__ == "__main__":
    main()
